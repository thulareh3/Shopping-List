import Axios from 'axios';
import MutationUtilities from '@/store/helpers/mutations';
import GetterUtilities from '@/store/helpers/getters';

const baseUrl = `${process.env.VUE_APP_ROOT_API}/shoppingLists`;

const actions = {
  Create: async (context, payload) => {
    try {
      context.commit('SetLoading', false);

      const requestObj = {
        config: {
          headers: {
            'Content-Type': 'application/json',
          },
        },
        data: payload,
        method: 'POST',
        url: baseUrl,
      };

      const { data } = await Axios(requestObj);

      if (![200, 201].includes(data.code)) {
        throw new Error(data.message);
      }
      return;
    } catch (error) {
      throw new Error(`Could not create an Item: ${error.message}`);
    } finally {
      context.dispatch('Load');
      context.commit('SetLoading', false);
    }
  },
  Load: (context) => new Promise((resolve, reject) => {
    context.commit('SetLoading', true);
    Axios.get(`${baseUrl}`)
      .then((response) => {
        context.commit('SetData', response.data);
        resolve();
      })
      .catch((error) => {
        reject(error.response);
      })
      .finally(() => {
        context.commit('SetLoading', false);
      });
  }),
  Modify: (context, payload) => new Promise((resolve, reject) => {
    context.commit('SetLoading', true);
    const requestObj = {
      config: {
        headers: {
          'Content-Type': 'application/json',
        },
      },
      data: payload,
      method: payload.id ? 'put' : 'post',
      url: `${baseUrl}/${payload.id}`,
    };

    Axios(requestObj)
      .then(() => {
        resolve();
      })
      .catch((error) => {
        reject(error.response.data.message);
      })
      .finally(() => {
        context.dispatch('Load');
        context.commit('SetLoading', false);
      });
  }),
  Delete: (context, payload) => new Promise((resolve, reject) => {
    context.commit('SetLoading', true);
    const requestObj = {
      config: {
        headers: {
          'Content-Type': 'application/json',
        },
      },
      data: payload,
      method: 'delete',
      url: `${baseUrl}/${payload.id}`,
    };

    Axios(requestObj)
      .then(() => {
        resolve();
      })
      .catch((error) => {
        reject(error.response.data.message);
      })
      .finally(() => {
        context.commit('SetLoading', false);
        context.dispatch('Load');
      });
  }),
};
const getters = {
  Data: GetterUtilities.getArrayCopy('data'),
  Loading: GetterUtilities.get('loading'),
};
const mutations = {
  SetData: MutationUtilities.set('data'),
  SetLoading: MutationUtilities.set('loading'),
};
const state = {
  data: null,
  loading: false,
};

export default {
  actions,
  getters,
  mutations,
  state,
};
