<template>
<validation-observer>
  <b-container class="text-center mt-5">
    <form id="shopping-list">
      <h2>Shopping List</h2>
      <b-alert show>You have {{itemsList.length}} items added</b-alert>
      <table id="shopping-list-table" class="table table-condensed table-hover">
        <thead>
          <tr>
            <th>Item</th>
            <th>Price</th>
            <th>Quantity</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tr v-for="(item, index) in itemsList" :key="`product-${index}`">
          <td>
            <span v-show="!item.inEditMode">{{ item.description }}</span>
            <b-form-input
              placeholder="description"
              v-show="item.inEditMode"
              v-model="item.description"
            />
          </td>
          <td>
            <span v-show="!item.inEditMode">{{ item.price }}</span>
            <b-form-input
             placeholder="price" v-show="item.inEditMode" v-model="item.price"
            />
          </td>
          <td>
            <span v-show="!item.inEditMode">{{ item.quantity }}</span>
            <b-form-input
              type="number"
              placeholder="quantity"
              v-show="item.inEditMode"
              v-model="item.quantity"
            />
          </td>
          <td>
            <b-button
              variant="success"
              v-show="item.inEditMode"
              @click="editItemComplete(item)"
            >
              Save
            </b-button>
            <b-button
              variant="info"
              v-show="!item.inEditMode"
              @click="editItem(item)"
            >
              <b-icon-pencil-square /> Edit
            </b-button>
            <b-button  variant="danger" @click="removeItem(item)">
              <b-icon-trash /> Delete
            </b-button>
          </td>
        </tr>
      </table>
      <b-card bg-variant="light">
        <b-form-group
          label-cols-lg="3"
          label="Add New Item"
          label-size="lg"
          label-class="font-weight-bold pt-0"
          class="mb-0"
        >
          <b-form-group
            label="Description:"
            label-for="description"
            label-cols-sm="3"
            label-align-sm="right"
          >
           <validation-provider
            v-slot="{ errors }"
            rules="required"
          >
            <b-form-input id="description" v-model="payload.description"></b-form-input>
            <validation-error-label :error="errors[0]" />
          </validation-provider>
          </b-form-group>

          <b-form-group
            label="Quantity:"
            label-for="quantity"
            label-cols-sm="3"
            label-align-sm="right"
          >
           <validation-provider
            v-slot="{ errors }"
            rules="required"
          >
            <b-form-input id="quantity" type="number" v-model="payload.quantity"></b-form-input>
              <validation-error-label :error="errors[0]" />
          </validation-provider>
          </b-form-group>

          <b-form-group label="Price:" label-for="price" label-cols-sm="3" label-align-sm="right">
             <validation-provider
            v-slot="{ errors }"
            rules="required"
          >
            <b-form-input id="price" v-model="payload.price"></b-form-input>
            <validation-error-label :error="errors[0]" />
          </validation-provider>
            <b-button @click="addItem" variant="primary" block class="mt-2 ml-0"
              ><b-icon-plus /> Add
            </b-button>
          </b-form-group>
        </b-form-group>
      </b-card>
    </form>
  </b-container>
</validation-observer>
</template>

<script>
import {
  BAlert,
  BButton,
  BFormGroup,
  BFormInput,
  BContainer,
  BIconPencilSquare,
  BIconPlus,
  BIconTrash,
} from 'bootstrap-vue';
import { ValidationObserver, ValidationProvider, extend } from 'vee-validate';
import ValidationErrorLabel from '@/components/ValidationErrorLabel.vue';
import { required } from 'vee-validate/dist/rules';
import { mapActions, mapGetters } from 'vuex';

extend('required', {
  ...required,
  message: 'This field is required',
});

export default {
  components: {
    BAlert,
    BButton,
    BContainer,
    BIconPencilSquare,
    BIconPlus,
    BIconTrash,
    BFormGroup,
    BFormInput,
    ValidationObserver,
    ValidationProvider,
    ValidationErrorLabel,
  },
  computed: {
    ...mapGetters({
      shoppingList: 'shoppingListStore/Data',
    }),
    itemsList() {
      return (this.shoppingList || [])
        .map((item) => ({
          ...item,
          inEditMode: this.inEditMode,
        }));
    },
  },
  data() {
    return {
      payload: {
        description: '',
        price: '',
        quantity: '',
      },
      inEditMode: false,
    };
  },
  methods: {
    ...mapActions({
      LoadShoppingList: 'shoppingListStore/Load',
      Create: 'shoppingListStore/Create',
      Delete: 'shoppingListStore/Delete',
      Edit: 'shoppingListStore/Modify',
    }),
    addItem() {
      this.Create(this.payload);
      this.clearAll();
    },
    clearAll() {
      this.payload = {
        description: '',
        price: '',
        quantity: '',
      };
    },
    removeItem(item) {
      this.Delete(item);
    },
    editItem() {
      // eslint-disable-next-line no-param-reassign
      this.inEditMode = true;
    },
    editItemComplete(item) {
      this.Edit(item);
      // eslint-disable-next-line no-param-reassign
      this.inEditMode = false;
    },
  },
  mounted() {
    this.LoadShoppingList();
  },
  name: 'shopping-list',
};
</script>
<style scoped>
body {
  padding: 1%;
  background-color: #abca;
}

h2,
h4 {
  font-family: 'Nunito', sans-serif;
}

#shopping-list-table {
  width: 100%;
}

button {
  margin-left: 2%;
}
</style>
