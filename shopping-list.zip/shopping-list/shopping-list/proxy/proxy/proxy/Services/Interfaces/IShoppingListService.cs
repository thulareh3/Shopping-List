﻿using CSharpFunctionalExtensions;
using proxy.Models;
using proxy.Services.Results;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace proxy.Services.Interfaces
{
    public interface IShoppingListService
    {
        Task<Result> CreateAsync(ShoppingList shoppingList);
        Task<ServiceResult> DeleteAsync(int id);
        Task<IEnumerable<ShoppingList>> GetAsync();
        Task<ServiceResult> UpdateAsync(int id, ShoppingList shoppingList);
    }
}
