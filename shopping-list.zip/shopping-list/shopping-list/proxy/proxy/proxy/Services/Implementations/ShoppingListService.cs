﻿using CSharpFunctionalExtensions;
using data_access_layer;
using Microsoft.EntityFrameworkCore;
using proxy.Models;
using proxy.Services.Interfaces;
using proxy.Services.Results;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace proxy.Services.Implementations
{
    public class ShoppingListService : IShoppingListService
    {
        private readonly DataAccessContext _context;
        public ShoppingListService(DataAccessContext context)
        {
            _context = context;
        }
        public async Task<Result> CreateAsync(ShoppingList shoppingList)
        {
            var model = new data_access_layer.Models.ShoppingList
            {
                Description = shoppingList.Description,
                Quantity = shoppingList.Quantity,
                Price = shoppingList.Price,
            };

            _context.ShoppingLists.Add(model);

            await _context
                .SaveChangesAsync()
                .ConfigureAwait(false);
            return Result.Success();
        }

        public async Task<ServiceResult> DeleteAsync(int id)
        {
            var model = _context.ShoppingLists.FirstOrDefault(a => a.Id == id);

            if (model == null)
            {
                return new ServiceResult
                {
                    Succeeded = false,
                    Error = "Item not found"
                };
            }


            _context.ShoppingLists.Remove(model);
            await _context.SaveChangesAsync();

            return new ServiceResult
            {
                Succeeded = true
            };
        }

        public async Task<IEnumerable<ShoppingList>> GetAsync()
        {
            return await _context
                .ShoppingLists
                .Select(m => new ShoppingList
                {
                    Id = m.Id,
                    Description =m.Description,
                    Quantity = m.Quantity,
                    Price = m.Price
                })
                .ToListAsync()
                .ConfigureAwait(false);
        }

        public async Task<ServiceResult> UpdateAsync(int id, ShoppingList shoppingList)
        {
            var model = _context.ShoppingLists.FirstOrDefault(a => a.Id == id);
            if (model == null)
            {
                return new ServiceResult
                {
                    Succeeded = false,
                    Error = "Item not found"
                };
            }

            model.Description = shoppingList.Description;
            model.Quantity = shoppingList.Quantity;
            model.Price = shoppingList.Price;
            await _context.SaveChangesAsync();

            return new ServiceResult
            {
                Succeeded = true
            };
        }
    }
}
