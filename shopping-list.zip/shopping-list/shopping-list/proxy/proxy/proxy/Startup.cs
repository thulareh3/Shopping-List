using data_access_layer;
using FluentValidation.AspNetCore;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Models;
using Newtonsoft.Json;
using proxy.Configurations;
using proxy.Infrastructure.Swagger;
using proxy.Services.Implementations;
using proxy.Services.Interfaces;
using System.Reflection;

namespace proxy
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            InitialiseMvc(services);
            InitialiseSwagger(services);
            InitialiseHealthChecks(services);
            InitialiseServices(services);
            InitialiseCors(services);
            InitialiseDatabase(services);
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            app.UseCors(Constants.General.AllowSpecificOriginsPolicyName);
            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
                endpoints.MapHealthChecks("/health");
            });
            app.UseSwagger();
            app.UseSwaggerUI(c => c.SwaggerEndpoint("v1/swagger.json", "shopping.list v1"));
        }
        private void InitialiseCors(IServiceCollection services)
        {
            var corsOpts = Configuration.GetSection("Cors").Get<CorsOptions>();

            services.AddCors(options =>
            {
                options.AddPolicy(Constants.General.AllowSpecificOriginsPolicyName,
                    builder => builder
                    .AllowAnyHeader()
                    .AllowAnyMethod()
                    .WithOrigins(corsOpts.GetAllowedOriginsAsArray()));
            });
        }
        private void InitialiseHealthChecks(IServiceCollection services)
        {
            services.AddHealthChecks();
        }
        private static void InitialiseSwagger(IServiceCollection services)
        {
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "Caxton.Proxy", Version = "v1" });
            });
        }
        private static void InitialiseMvc(IServiceCollection services)
        {
            services.AddControllers(o => o.Conventions.Add(new ApiExplorerIgnores()))
                .AddNewtonsoftJson(
                    opts => opts
                    .SerializerSettings
                    .NullValueHandling = NullValueHandling.Ignore)
                .AddFluentValidation(fvc => fvc.RegisterValidatorsFromAssemblyContaining<Startup>());

        }
        private void InitialiseServices(IServiceCollection services)
        {
            services.AddScoped<IShoppingListService, ShoppingListService>();
        }
        private void InitialiseDatabase(IServiceCollection services)
        {
            var migrationsAssembly = typeof(DataAccessContext).GetTypeInfo().Assembly.GetName().Name;

            services.AddDbContext<DataAccessContext>(
            options =>
            options.UseSqlServer(
            Configuration.GetConnectionString("ApplicationDb"),
            b => b.MigrationsAssembly(migrationsAssembly)));
        }
    }
}
