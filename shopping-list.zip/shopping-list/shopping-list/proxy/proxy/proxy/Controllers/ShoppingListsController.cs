﻿using CSharpFunctionalExtensions;
using Microsoft.AspNetCore.Mvc;
using proxy.Models;
using proxy.Services.Interfaces;
using proxy.Services.Results;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace proxy.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ShoppingListsController : ControllerBase
    {
        private readonly IShoppingListService _shoppingListService;
        public ShoppingListsController(IShoppingListService shoppingListService)
        {
            _shoppingListService = shoppingListService;
        }
        [HttpGet]
        public Task<IEnumerable<ShoppingList>> Get()
        {
            return _shoppingListService.GetAsync();
        }
        [HttpPost]
        public Task<Result> Create(ShoppingList model)
        {
            return _shoppingListService.CreateAsync(model);
        }
        [HttpPut]
        [Route("{id}")]
        public Task<ServiceResult> Update(int id, ShoppingList shoppingList)
        {
            return _shoppingListService.UpdateAsync(id, shoppingList);
        }
        [HttpDelete]
        [Route("{id}")]
        public Task<ServiceResult> Delete(int id)
        {
            return _shoppingListService.DeleteAsync(id);
        }
    }
}
