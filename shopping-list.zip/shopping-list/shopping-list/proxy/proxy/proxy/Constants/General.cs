﻿namespace proxy.Constants
{
    public static class General
    {
        public const string AllowSpecificOriginsPolicyName = "AllowSpecificOrigins";
    }
}
