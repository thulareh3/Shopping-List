﻿using System.Linq;

namespace proxy.Configurations
{
    public class CorsOptions
    {
        public string AllowedOrigins { get; set; }

        public string[] GetAllowedOriginsAsArray()
        {
            return AllowedOrigins
                .Split(',')
                .Select(o => o.Trim())
                .ToArray();
        }
    }
}
