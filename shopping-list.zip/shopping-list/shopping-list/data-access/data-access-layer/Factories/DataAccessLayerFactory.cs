﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;

namespace data_access_layer.Factories
{
    public class DataAccessLayerFactory
    : IDesignTimeDbContextFactory<DataAccessContext>
    {
        public DataAccessContext CreateDbContext(string[] args)
        {
            var optionsBuilder = new DbContextOptionsBuilder<DataAccessContext>();

            optionsBuilder.UseSqlServer(
                @"Server =AG2368\SQLEXPRESS; Database = ShoppingList; Trusted_Connection = True;");

            return new DataAccessContext(optionsBuilder.Options);
        }
    }
}
