﻿using data_access_layer.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace data_access_layer.Configurations
{
    public class ShoppingListConfig : IEntityTypeConfiguration<ShoppingList>
    {
        public void Configure(EntityTypeBuilder<ShoppingList> builder)
        {
            builder
                .Property(e => e.Description)
                .IsRequired()
                .HasMaxLength(200);

            builder
                .Property(e => e.Price)
                .IsRequired();

            builder
               .Property(e => e.Quantity)
               .IsRequired();
        }
    }
}
